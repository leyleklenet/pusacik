# Pusacık Android
Android WebView application for https://www.pusacik.com.tr/.
Build: Gradle 8.10.2, JDK 17, Android SDK 35; `gradle assembleDebug`.
This is a debug/testing build; production release requires further security, UX, and signing work.
